import { Component } from '@angular/core';

@Component({
  selector: 'app-userbox2',
  imports: [],
  templateUrl: './userbox.component.html',
  styleUrl: './userbox.component.css'
})
export class UserboxComponent {

}
